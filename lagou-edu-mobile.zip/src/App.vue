<template>
  <div id="app">
    <!-- 跟路由出口 -->
    <router-view/>
  </div>
</template>

<style lang="scss">

</style>
