<template>
  <div class="course-video">
  </div>
</template>

<script>
export default {
  name: 'CourseVideo',
  props: {
    lessonId: {
      type: [String, Number],
      required: true
    }
  }

}
</script>

<style lang='scss' scoped>

</style>
