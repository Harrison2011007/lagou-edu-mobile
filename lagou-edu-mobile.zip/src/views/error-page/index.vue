<template>
  <div class="error-page">找不到访问的页面...</div>
</template>

<script>
export default {
  name: 'ErrorPage'

}
</script>

<style lang='scss' scoped>

</style>
